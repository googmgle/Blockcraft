package com.blockcraft.game;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;

public class GameView extends FrameLayout {
    private final BlockRenderer renderer;
    private float lastX, lastY;
    private boolean draggingLook = false;
    private float forward = 0, strafe = 0;

    public GameView(Context context) {
        super(context);
        GLSurfaceView gl = new GLSurfaceView(context);
        gl.setEGLContextClientVersion(2);
        renderer = new BlockRenderer();
        gl.setRenderer(renderer);
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        addView(gl, new FrameLayout.LayoutParams(-1, -1));

        TextView hint = new TextView(context);
        hint.setText("LEFT: MOVE     RIGHT: LOOK     BREAK / PLACE");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(12);
        hint.setPadding(12, 8, 12, 8);
        hint.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(hint, hp);

        LinearLayout pad = new LinearLayout(context);
        pad.setOrientation(LinearLayout.VERTICAL);
        String[][] labels = {{"▲"}, {"◀", "▼", "▶"}};
        for (String[] row : labels) {
            LinearLayout r = new LinearLayout(context);
            r.setGravity(Gravity.CENTER);
            for (String s : row) {
                Button b = new Button(context);
                b.setText(s);
                b.setTextSize(14);
                r.addView(b, new LinearLayout.LayoutParams(64, 58));
                b.setOnTouchListener((v, e) -> {
                    int action = e.getActionMasked();
                    boolean down = action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE;
                    if (s.equals("▲")) forward = down ? 1 : 0;
                    if (s.equals("▼")) forward = down ? -1 : 0;
                    if (s.equals("◀")) strafe = down ? -1 : 0;
                    if (s.equals("▶")) strafe = down ? 1 : 0;
                    renderer.setMovement(forward, strafe);
                    return true;
                });
            }
            pad.addView(r);
        }
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        pp.setMargins(12, 0, 0, 10);
        addView(pad, pp);

        LinearLayout actions = new LinearLayout(context);
        Button breakBtn = new Button(context); breakBtn.setText("BREAK");
        Button placeBtn = new Button(context); placeBtn.setText("PLACE");
        actions.addView(breakBtn); actions.addView(placeBtn);
        FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.RIGHT);
        ap.setMargins(0, 0, 12, 10);
        addView(actions, ap);
        breakBtn.setOnClickListener(v -> renderer.breakBlock());
        placeBtn.setOnClickListener(v -> renderer.placeBlock());

        setOnTouchListener((v, e) -> {
            if (e.getX() > getWidth() * 0.48f) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    lastX = e.getX(); lastY = e.getY(); draggingLook = true;
                } else if (e.getAction() == MotionEvent.ACTION_MOVE && draggingLook) {
                    float dx = e.getX() - lastX;
                    float dy = e.getY() - lastY;
                    lastX = e.getX(); lastY = e.getY();
                    renderer.look(dx * 0.25f, dy * 0.18f);
                } else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    draggingLook = false;
                }
                return true;
            }
            return false;
        });
    }
}
