package com.blockcraft.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showMenu();
    }

    private void showMenu() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.rgb(28, 43, 55));
        TextView title = new TextView(this);
        title.setText("BLOCKCRAFT");
        title.setTextColor(Color.WHITE);
        title.setTextSize(38);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Build. Explore. Survive.");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        layout.addView(subtitle);
        Button play = new Button(this);
        play.setText("SINGLEPLAYER");
        layout.addView(play);
        Button settings = new Button(this);
        settings.setText("SETTINGS");
        layout.addView(settings);
        Button mods = new Button(this);
        mods.setText("MODS");
        layout.addView(mods);
        play.setOnClickListener(v -> setContentView(new GameView(this)));
        settings.setOnClickListener(v -> showMessage("Settings", "Touch sensitivity and graphics options are coming in a later update."));
        mods.setOnClickListener(v -> showMessage("Mods", "The mod loader is planned for a future version."));
        setContentView(layout);
    }

    private void showMessage(String title, String message) {
        new android.app.AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setPositiveButton("OK", null).show();
    }

    @Override public void onBackPressed() {
        showMenu();
    }
}
