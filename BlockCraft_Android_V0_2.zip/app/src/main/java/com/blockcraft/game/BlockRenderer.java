package com.blockcraft.game;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class BlockRenderer implements GLSurfaceView.Renderer {
    private static final int SIZE = 24;
    private final int[][][] world = new int[SIZE][10][SIZE];
    private int program, aPos, aColor, uMvp;
    private FloatBuffer vertices, colors;
    private final float[] projection = new float[16], view = new float[16], model = new float[16], mvp = new float[16];
    private float playerX = 12, playerZ = 12, yaw = 0, pitch = -12;
    private float forward = 0, strafe = 0;
    private long lastTime;
    private int selected = 1;

    public BlockRenderer() {
        Random r = new Random(12);
        for (int x=0; x<SIZE; x++) for (int z=0; z<SIZE; z++) {
            int h = 2 + (int)(1.5 * Math.sin(x * .35) + 1.2 * Math.cos(z * .28)) + r.nextInt(2);
            h = Math.max(1, Math.min(5, h));
            for (int y=0; y<h; y++) world[x][y][z] = (y == h-1) ? 1 : 2;
            if (r.nextFloat() < .035f && h < 7) {
                for (int y=h; y<h+3 && y<10; y++) world[x][y][z] = 3;
                for (int dx=-1; dx<=1; dx++) for (int dz=-1; dz<=1; dz++)
                    if (x+dx>=0 && x+dx<SIZE && z+dz>=0 && z+dz<SIZE && h+3<10)
                        world[x+dx][h+3][z+dz] = 4;
            }
        }
        rebuildBuffers();
    }

    public void setMovement(float f, float s) { forward=f; strafe=s; }
    public void look(float dx, float dy) { yaw += dx; pitch = Math.max(-75, Math.min(55, pitch + dy)); }

    public void breakBlock() {
        int[] p = targetBlock();
        if (p != null) { world[p[0]][p[1]][p[2]] = 0; rebuildBuffers(); }
    }
    public void placeBlock() {
        int[] p = targetBlock();
        if (p != null) {
            int x=p[0], y=p[1], z=p[2];
            float fx = (float)Math.sin(Math.toRadians(yaw)), fz = (float)-Math.cos(Math.toRadians(yaw));
            int nx = x - Math.round(fx), nz = z - Math.round(fz);
            if (nx>=0 && nx<SIZE && nz>=0 && nz<SIZE && y>=0 && y<10 && world[nx][y][nz]==0) {
                world[nx][y][nz]=selected; rebuildBuffers();
            }
        }
    }
    private int[] targetBlock() {
        float fx=(float)Math.sin(Math.toRadians(yaw)), fz=(float)-Math.cos(Math.toRadians(yaw));
        for (int d=2; d<6; d++) {
            int x=Math.round(playerX+fx*d), z=Math.round(playerZ+fz*d);
            int y=2;
            if (x>=0 && x<SIZE && z>=0 && z<SIZE && world[x][y][z]!=0) return new int[]{x,y,z};
        }
        return null;
    }

    private void rebuildBuffers() {
        float[] verts = new float[SIZE*SIZE*10*6*6*3];
        float[] cols = new float[verts.length/3*4/3];
        int vi=0, ci=0;
        float[][] face = {
            {-0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f},
            {0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f},
            {-0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f},
            {-0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f},
            {0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f},
            {-0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f}
        };
        float[][] base={{.25f,.68f,.22f},{.43f,.28f,.16f},{.48f,.49f,.52f},{.48f,.29f,.13f},{.15f,.52f,.18f}};
        float[] shade={.78f,.9f,1f,.62f,.82f,.72f};
        for(int x=0;x<SIZE;x++) for(int y=0;y<10;y++) for(int z=0;z<SIZE;z++) {
            int type=world[x][y][z]; if(type==0) continue;
            for(int f=0;f<6;f++) {
                float light=shade[f];
                for(int v=0;v<18;v+=3) {
                    verts[vi++]=face[f][v]+x; verts[vi++]=face[f][v+1]+y; verts[vi++]=face[f][v+2]+z;
                    cols[ci++]=base[type][0]*light; cols[ci++]=base[type][1]*light; cols[ci++]=base[type][2]*light; cols[ci++]=1;
                }
            }
        }
        vertices=ByteBuffer.allocateDirect(vi*4).order(ByteOrder.nativeOrder()).asFloatBuffer(); vertices.put(verts,0,vi).position(0);
        colors=ByteBuffer.allocateDirect(ci*4).order(ByteOrder.nativeOrder()).asFloatBuffer(); colors.put(cols,0,ci).position(0);
    }

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        String vs="attribute vec3 aPosition; attribute vec4 aColor; uniform mat4 uMVP; varying vec4 vColor; void main(){gl_Position=uMVP*vec4(aPosition,1.0);vColor=aColor;}";
        String fs="precision mediump float; varying vec4 vColor; void main(){gl_FragColor=vColor;}";
        int v=shader(GLES20.GL_VERTEX_SHADER,vs), f=shader(GLES20.GL_FRAGMENT_SHADER,fs);
        program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,v); GLES20.glAttachShader(program,f); GLES20.glLinkProgram(program);
        aPos=GLES20.glGetAttribLocation(program,"aPosition"); aColor=GLES20.glGetAttribLocation(program,"aColor"); uMvp=GLES20.glGetUniformLocation(program,"uMVP");
        lastTime=System.nanoTime();
    }
    private int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s;}
    @Override public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,70,(float)w/h,.1f,100f);}
    @Override public void onDrawFrame(GL10 gl){
        long now=System.nanoTime(); float dt=Math.min(.05f,(now-lastTime)/1e9f); lastTime=now;
        float a=(float)Math.toRadians(yaw);
        playerX += ((float)Math.sin(a)*forward+(float)Math.cos(a)*strafe)*dt*4;
        playerZ += (-(float)Math.cos(a)*forward+(float)Math.sin(a)*strafe)*dt*4;
        playerX=Math.max(0.5f,Math.min(SIZE-0.5f,playerX)); playerZ=Math.max(0.5f,Math.min(SIZE-0.5f,playerZ));
        GLES20.glClearColor(.48f,.72f,.92f,1); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        float fx=(float)Math.sin(a), fz=-(float)Math.cos(a);
        Matrix.setLookAtM(view,0,playerX,5.2f,playerZ,playerX+fx,5.0f+(float)Math.sin(Math.toRadians(pitch)),playerZ+fz,0,1,0);
        Matrix.setIdentityM(model,0); Matrix.multiplyMM(mvp,0,view,0,model,0); Matrix.multiplyMM(mvp,0,projection,0,mvp,0);
        GLES20.glUseProgram(program); GLES20.glUniformMatrix4fv(uMvp,1,false,mvp,0);
        vertices.position(0); colors.position(0);
        GLES20.glEnableVertexAttribArray(aPos); GLES20.glVertexAttribPointer(aPos,3,GLES20.GL_FLOAT,false,0,vertices);
        GLES20.glEnableVertexAttribArray(aColor); GLES20.glVertexAttribPointer(aColor,4,GLES20.GL_FLOAT,false,0,colors);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertices.limit()/3);
        GLES20.glDisableVertexAttribArray(aPos); GLES20.glDisableVertexAttribArray(aColor);
    }
}
