# BlockCraft Android V0.2

This is the Android Studio source project for BlockCraft, an original voxel sandbox prototype.

## Build an APK
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Open this folder in Android Studio.
3. Let Gradle sync finish. Use JDK 17 if Android Studio asks.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location when the build succeeds.

The APK is not included because this download is the editable Android project source. It must be compiled with the Android SDK/build tools.

## V0.2 features
- Landscape Android game view
- OpenGL ES 2.0 block terrain with shaded cube faces
- Hills and simple block trees
- On-screen directional movement pad
- Drag on the right side to look around
- Basic break/place buttons and a simple block target check
- Main menu with Singleplayer, Settings, and Mods entries

## Prototype limitations
This is an early prototype, not a finished Minecraft replacement. Block targeting is deliberately simple, the player is kept within the world bounds but does not yet have full terrain collision or jumping, and the world is generated in memory and is not saved. Settings and Mods are menu placeholders. Rendering currently uses shaded block colours rather than a finished pixel texture atlas. The project source has not been compiled or tested on a physical phone in this environment.
